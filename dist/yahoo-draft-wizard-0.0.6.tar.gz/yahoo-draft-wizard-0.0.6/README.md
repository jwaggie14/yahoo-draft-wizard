# yahoowizard
the package connects to yahoo's fantasy football api to monitor and to make recommendations for your draft.

Initial release. Version 0.0.3. Very developmental - no promises at all.

# Installation
Install with ```pip install yahoo-draft-wizard```

You can find supporting files here: https://github.com/jwaggie14/ydw-supporting-files
